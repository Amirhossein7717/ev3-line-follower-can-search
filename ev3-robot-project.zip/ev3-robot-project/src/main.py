#!/usr/bin/env python3
"""
EV3 Line Follower + Can Search (Ultrasonic Arc Scan)
====================================================
Author : Amirhossein Taleshinosrati
Team   : Multi-Robot Systems Project — SDU, Denmark (2025)
         (Mounir Abbary, Nicolas Lambropoulos, and team)

Description:
    LEGO Mindstorms EV3 robot programmed in Python (ev3dev) that:
      - Follows a line using a PID controller with two color sensors
      - Detects the end of the line using a stable white-white condition
      - Runs an interruptible ultrasonic arc scan to search for a can/object
      - Returns to the line using motor encoders, then resumes line following

Hardware:
    Motors:
        Left  motor : outA
        Right motor : outD
    Sensors:
        Color sensor (left) : in3 -> COL-REFLECT
        Color sensor (right): in4 -> COL-REFLECT
        Ultrasonic sensor   : in2 -> US-DIST-CM

Usage (ev3dev):
    scp -r ev3-line-follower-can-search robot@ev3dev.local:~/
    ssh robot@ev3dev.local
    cd ev3-line-follower-can-search
    python3 src/main.py
"""

from ev3dev2.motor import LargeMotor, OUTPUT_A, OUTPUT_D, SpeedPercent
from ev3dev2.sensor import INPUT_2, INPUT_3, INPUT_4
from ev3dev2.sensor.lego import ColorSensor, UltrasonicSensor
from ev3dev2.button import Button
import time

# ─── HARDWARE INIT ────────────────────────────────────────────────────────────
mL = LargeMotor(OUTPUT_A)   # Left motor
mR = LargeMotor(OUTPUT_D)   # Right motor
clLeft  = ColorSensor(INPUT_3)
clRight = ColorSensor(INPUT_4)
us      = UltrasonicSensor(INPUT_2)
btn     = Button()

clLeft.mode  = 'COL-REFLECT'
clRight.mode = 'COL-REFLECT'
us.mode      = 'US-DIST-CM'

# ─── PID LINE FOLLOWING PARAMETERS ───────────────────────────────────────────
baseline     = 30       # Base motor duty cycle
P_GAIN       = 1.2      # Proportional gain
I_GAIN       = 0.05     # Integral gain
D_GAIN       = 0.8      # Derivative gain
INTEGRAL_LIM = 50       # Integral clamp

# ─── END-OF-LINE DETECTION ────────────────────────────────────────────────────
soglia_bianco  = 60     # White threshold (tune to your track lighting)
CONTRAST_EPS   = 10     # Max difference between sensors for white-white
LINE_LOST_LIMIT = 8     # Consecutive samples to confirm end of line

# ─── CAN SEARCH PARAMETERS ────────────────────────────────────────────────────
CAN_MIN_CM   = 5        # Minimum distance to can
CAN_MAX_CM   = 30       # Maximum distance to can
ARC_WIDE     = 180      # Total scan arc in degrees
ARC_WIDE_STEP = 10      # Step size per scan sample
K_TURN       = 5.6      # Calibration: ticks per degree of turn
WHEEL_DIAM_MM = 56.0    # Wheel diameter in mm
DRIVE_SIGN   = 1        # 1=forward, -1=backward
SCALE        = 1.0      # Encoder return correction factor

# ─── TIMING ───────────────────────────────────────────────────────────────────
dt = 0.02               # Loop timestep in seconds


# ─── HELPERS ──────────────────────────────────────────────────────────────────
def turn_deg(deg):
    """Turn robot by deg degrees using motor encoders."""
    ticks = int(deg * K_TURN)
    mL.run_to_rel_pos(position_sp=ticks,  speed_sp=200, stop_action='brake')
    mR.run_to_rel_pos(position_sp=-ticks, speed_sp=200, stop_action='brake')
    mL.wait_while('running')
    mR.wait_while('running')


def drive_cm(cm):
    """Drive forward/backward by cm centimetres using motor encoders."""
    ticks = int((cm * 10 / (3.14159 * WHEEL_DIAM_MM)) * 360)
    mL.run_to_rel_pos(position_sp=DRIVE_SIGN * ticks, speed_sp=200, stop_action='brake')
    mR.run_to_rel_pos(position_sp=DRIVE_SIGN * ticks, speed_sp=200, stop_action='brake')
    mL.wait_while('running')
    mR.wait_while('running')


def stop_motors():
    mL.stop(stop_action='brake')
    mR.stop(stop_action='brake')


def is_white(val):
    return val > soglia_bianco


def sees_line():
    """Return True if either sensor detects a dark line."""
    return (not is_white(clLeft.value())) or (not is_white(clRight.value()))


# ─── CAN SEARCH ───────────────────────────────────────────────────────────────
def search_can():
    """
    Arc scan to locate can/object:
      1. Move slightly away from end zone
      2. Scan arc, record (angle, distance) samples
      3. Find window in target range
      4. Aim to window centre + short approach
      5. Return to start encoder position
    """
    print("[SEARCH] Starting arc scan...")

    # Save start position
    start_posL = mL.position
    start_posR = mR.position

    # Move away from line end
    drive_cm(5)
    time.sleep(0.2)

    # Arc scan
    samples = []
    half_arc = ARC_WIDE // 2
    turn_deg(-half_arc)   # Turn left to start of scan

    for angle in range(-half_arc, half_arc + 1, ARC_WIDE_STEP):
        dist = us.value() / 10.0   # Convert mm -> cm
        samples.append((angle, dist))
        print(f"  angle={angle:4d}° dist={dist:.1f}cm")

        # Interruptible: if line detected, abort immediately
        if sees_line():
            print("[SEARCH] Line detected during scan — aborting!")
            break

        turn_deg(ARC_WIDE_STEP)
        time.sleep(0.05)

    # Find detection window
    window = [(a, d) for a, d in samples if CAN_MIN_CM <= d <= CAN_MAX_CM]

    if window:
        centre_angle = sum(a for a, _ in window) / len(window)
        print(f"[SEARCH] Can detected! Window centre = {centre_angle:.1f}°")
        # Aim to centre
        current_angle = samples[-1][0]
        turn_deg(centre_angle - current_angle)
        drive_cm(3)   # Short approach
        time.sleep(0.5)
    else:
        print("[SEARCH] No can found in range.")

    # Return to start pose
    print("[SEARCH] Returning to line...")
    returnL = int((start_posL - mL.position) * SCALE)
    returnR = int((start_posR - mR.position) * SCALE)
    mL.run_to_rel_pos(position_sp=returnL, speed_sp=300, stop_action='brake')
    mR.run_to_rel_pos(position_sp=returnR, speed_sp=300, stop_action='brake')
    mL.wait_while('running')
    mR.wait_while('running')
    print("[SEARCH] Done. Resuming line follow.")


# ─── MAIN LOOP ────────────────────────────────────────────────────────────────
def main():
    print("=== EV3 Line Follower + Can Search ===")
    print("Press any button to stop.\n")

    integral    = 0.0
    prev_error  = 0.0
    lost_count  = 0
    last_error  = 0.0

    mL.reset()
    mR.reset()

    while not btn.any():
        left_val  = clLeft.value()
        right_val = clRight.value()

        # ── End-of-line detection ──────────────────────────────────────────
        if is_white(left_val) and is_white(right_val) and \
           abs(left_val - right_val) < CONTRAST_EPS:
            lost_count += 1
            if lost_count >= LINE_LOST_LIMIT:
                print("[EOL] End of line confirmed.")
                stop_motors()
                # Pivot recovery: back up slightly
                drive_cm(-3)
                search_can()
                lost_count = 0
                integral   = 0.0
                prev_error = 0.0
                continue
        else:
            lost_count = 0

        # ── PID line following ─────────────────────────────────────────────
        error      = float(left_val - right_val)
        integral   = max(-INTEGRAL_LIM, min(INTEGRAL_LIM, integral + error * dt))
        derivative = (error - prev_error) / dt
        correction = P_GAIN * error + I_GAIN * integral + D_GAIN * derivative
        prev_error = error
        last_error = error

        # Clamp correction
        max_corr = baseline * 1.5
        correction = max(-max_corr, min(max_corr, correction))

        mL.run_direct(duty_cycle_sp=int(baseline + correction))
        mR.run_direct(duty_cycle_sp=int(baseline - correction))

        time.sleep(dt)

    stop_motors()
    print("=== Stopped ===")


if __name__ == '__main__':
    main()
