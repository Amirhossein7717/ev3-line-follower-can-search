# 🤖 EV3 Line Follower + Can Search

**LEGO Mindstorms EV3 robot** programmed in Python (ev3dev) that:
- Follows a line using a **PID controller** with two colour sensors
- Detects the **end of the line** using a stable white-white condition
- Runs an **interruptible ultrasonic arc scan** to search for a can/object
- **Returns to the line** using motor encoders, then resumes line following

> 📍 Multi-Robot Systems Project — University of Southern Denmark (SDU), 2025

---

## 🎥 Demo

▶️ [YouTube demo (Shorts)](https://youtube.com/shorts/Z8Ef_XxjmJM?feature=share)

---

## ✨ Key Features

- ✅ **PID line following** (P/I/D) with integral clamping to avoid windup
- ✅ **Gap vs. end-of-line logic** using:
  - `soglia_bianco` (white threshold)
  - `CONTRAST_EPS` (sensor similarity check)
  - `LINE_LOST_LIMIT` (time confirmation)
- ✅ **Search behaviour** at end-of-line:
  - Short move away from the end zone
  - Arc scan collecting `(angle, distance_cm)` samples
  - Detection of a distance window within a target range
  - Aim to the window centre + short approach
  - Encoder-based return + resume line following
- ✅ **Interruptible scan**: if the robot sees the line during scanning, it aborts and returns immediately to line-follow mode

---

## 🧱 Hardware Setup

| Component | Port |
|---|---|
| Left motor | `outA` |
| Right motor | `outD` |
| Color sensor (left) | `in3` → COL-REFLECT |
| Color sensor (right) | `in4` → COL-REFLECT |
| Ultrasonic sensor | `in2` → US-DIST-CM |

> If your wiring/ports differ, update them at the top of `src/main.py`.

---

## 📁 Project Structure

```
ev3-line-follower-can-search/
├─ README.md
├─ src/
│  └─ main.py          # Main robot program
├─ docs/
│  └─ report-ev3.pdf   # Full project report
└─ videos/
   └─ links.md         # Demo video links
```

---

## ⚙️ How to Run (ev3dev)

### 1) Copy the project to the EV3
```bash
scp -r ev3-line-follower-can-search robot@ev3dev.local:~/
```

### 2) SSH into the EV3
```bash
ssh robot@ev3dev.local
```

### 3) Run the script
```bash
cd ev3-line-follower-can-search
python3 src/main.py
```

> If `import ev3dev2` fails, verify you are using an ev3dev image with Python bindings installed.

---

## 🧠 System Overview

### Line Following (PID)
Reflected light is read from both sensors:
```python
left_val  = clLeft.value()
right_val = clRight.value()
error     = left_val - right_val
correction = P*error + I*integral + D*derivative
```
- **Integral clamping** (`INTEGRAL_LIM`) reduces windup
- **Correction cap** (relative to base speed) improves stability at higher speeds

### End-of-Line Detection
The robot confirms end-of-line when:
- Both sensors read white (`> soglia_bianco`)
- Values are similar (`abs(left - right) < CONTRAST_EPS`)
- Stable for `~LINE_LOST_LIMIT × dt` seconds

### Can/Object Search (Ultrasonic Arc Scan)
Triggered after end-of-line is confirmed:
1. Store start encoder positions
2. Move slightly away from the end zone
3. Scan an arc and log `(angle, distance_cm)` samples
4. Detect a window of angles where distance falls inside `[CAN_MIN_CM, CAN_MAX_CM]`
5. Aim to the window centre and approach slightly
6. Return to start pose using encoders and resume line following

---

## 🔧 Tuning Parameters

### Line Following
| Parameter | Description |
|---|---|
| `baseline` | Base motor duty cycle (higher = faster, less stable) |
| `P_GAIN` | Proportional gain (too high → oscillations) |
| `I_GAIN` | Integral gain (helps drift; too high → slow wobble) |
| `D_GAIN` | Derivative gain (damping; too high → noisy) |
| `INTEGRAL_LIM` | Integral clamp (prevents windup) |
| `soglia_bianco` | White threshold (depends on light/track) |
| `CONTRAST_EPS` | Similarity for white-white (lower = stricter) |
| `LINE_LOST_LIMIT` | Samples to confirm end (higher = fewer false triggers) |

### Search Behaviour
| Parameter | Description |
|---|---|
| `CAN_MIN_CM`, `CAN_MAX_CM` | Distance range for target |
| `ARC_WIDE`, `ARC_WIDE_STEP` | Scan arc + resolution |
| `K_TURN` | Turning calibration (deg → ticks) |
| `WHEEL_DIAM_MM` | Distance conversion |
| `DRIVE_SIGN` | Forward/backward sign |
| `SCALE` | Encoder return correction factor |

---

## 🩹 Troubleshooting

| Problem | Solution |
|---|---|
| Oscillations on the line | Reduce `P_GAIN`, increase `D_GAIN` slightly, reduce `baseline` |
| Slow drift | Increase `I_GAIN` slightly (keep `INTEGRAL_LIM`) |
| False end-of-line triggers | Increase `LINE_LOST_LIMIT`, adjust `soglia_bianco` / `CONTRAST_EPS` |
| Doesn't detect the object | Check printed ultrasonic values; adjust `CAN_MIN_CM` / `CAN_MAX_CM` |
| Inaccurate turns/return | Battery and friction matter; recalibrate `K_TURN` and `SCALE` |

---

## 📄 Documentation

Full project report: [`docs/report-ev3.pdf`](docs/report-ev3.pdf)

---

## 👤 Author

**Amirhossein Taleshinosrati**
- 🔗 GitHub: [github.com/amirhossein-taleshinosrati](https://github.com/amirhossein-taleshinosrati)
- 💼 LinkedIn: [linkedin.com/in/amirhossein-taleshinosrati](https://linkedin.com/in/amirhossein-taleshinosrati)
- 📧 amirhossein.taleshii@gmail.com

**Project teammates:** Mounir Abbary · Nicolas Lambropoulos · and team @ SDU Denmark

---

## 🧾 License

This project is licensed under the [MIT License](LICENSE).
